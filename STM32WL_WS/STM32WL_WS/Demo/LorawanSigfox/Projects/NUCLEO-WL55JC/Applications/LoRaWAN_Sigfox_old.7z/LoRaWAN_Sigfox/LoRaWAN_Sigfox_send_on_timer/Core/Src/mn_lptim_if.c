/**
  ******************************************************************************
  * @file    mn_lptim_if.c
  * @author  MCD Application Team
  * @brief   Interface between Sigfox monarch and lptim
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "lptim.h"
#include "mn_lptim_if.h"

/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* External variables ---------------------------------------------------------*/
/**
  * @brief LPTIM handle
  */
extern LPTIM_HandleTypeDef hlptim1;

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Exported functions --------------------------------------------------------*/
void MN_LPTIM_IF_Init(void)
{
  /* USER CODE BEGIN MN_LPTIM_IF_Init_0 */
  /* USER CODE END MN_LPTIM_IF_Init_0 */

  /* Force the LPTIM1 Periheral Clock Reset */
  __HAL_RCC_LPTIM1_FORCE_RESET();
  /* Release the LPTIM1 Periheral Clock Reset */
  __HAL_RCC_LPTIM1_RELEASE_RESET();

  /* USER CODE BEGIN MN_LPTIM_IF_Init_1 */
  /* USER CODE END MN_LPTIM_IF_Init_1 */

  MX_LPTIM1_Init();

  /* USER CODE BEGIN MN_LPTIM_IF_Init_2 */
  /* USER CODE END MN_LPTIM_IF_Init_2 */

  /* w.a.: LL_EXTI_LINE_X should be enabled in HAL_LPTIM_MspInit */
  LL_EXTI_EnableIT_0_31(LL_EXTI_LINE_29);

  /* USER CODE BEGIN MN_LPTIM_IF_Init_3 */
  /* USER CODE END MN_LPTIM_IF_Init_3 */
}

void MN_LPTIM_IF_DeInit(void)
{
  RCC_PeriphCLKInitTypeDef RCC_PeriphCLKInitStruct;

  /* USER CODE BEGIN MN_LPTIM_IF_DeInit_0 */
  /* USER CODE END MN_LPTIM_IF_DeInit_0 */

  if (HAL_LPTIM_DeInit(&hlptim1) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN MN_LPTIM_IF_DeInit_1 */
  /* USER CODE END MN_LPTIM_IF_DeInit_1 */

  /* Select the PCLK clock as LPTIM1 peripheral clock */
  RCC_PeriphCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LPTIM1;
  RCC_PeriphCLKInitStruct.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_PCLK1;
  HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitStruct);

  /* USER CODE BEGIN MN_LPTIM_IF_DeInit_2 */
  /* USER CODE END MN_LPTIM_IF_DeInit_2 */

  /* Force the LPTIM1 Periheral Clock Reset */
  __HAL_RCC_LPTIM1_FORCE_RESET();

  /* Release the LPTIM1 Periheral Clock Reset */
  __HAL_RCC_LPTIM1_RELEASE_RESET();

  /* USER CODE BEGIN MN_LPTIM_IF_DeInit_3 */
  /* USER CODE END MN_LPTIM_IF_DeInit_3 */

}

/* USER CODE BEGIN EF */

/* USER CODE END EF */

/* Private Functions Definition -----------------------------------------------*/
/* USER CODE BEGIN PrFD */

/* USER CODE END PrFD */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
